# Show Attributes on product home page

