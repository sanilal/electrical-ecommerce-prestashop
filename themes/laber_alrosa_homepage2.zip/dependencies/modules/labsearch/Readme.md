Advanced Ajax Live Search Product


Short Description:
Ajax Live Search Product helps customers to save time searching for desired product, find results significantly faster


Benefits for Merchants:
Our ajax search module will improve the store frontend with new great features. 
Flexible autocomplete search configuration will help you to perfect the search suggest results at your store.
Impress your visitors and increase your site usability!

 
Install:
This easy at installation and flexible at configuration module allows you to create attractive Advanced Ajax Live Search Product in a couple of minutes!

Features:

Super easy install and customize.
Completely configurable through admin interface.
Speed up the search process.
Build a friendly search in your store.
Number item show in result search.
Compatible with all web browsers.
Multi-language and Multi-store ready.
Support and well documented.

search, live, ajax, product, searching, products, autocomplete, help, support, visitors, client, images, contact, price, customers